

const texto = ["texto","es","grande","pero","no","precisamnete"];

let longestIndex = 0; 
for (let i = 1; i < texto.length; i++) {
  if (texto[i].length > texto[longestIndex].length) {
    longestIndex = i;
  }
}
console.log( longestIndex);


const lista = [1, 8, 5, 22 , 12];
const suma = lista.reduce((a, b) => a + b, 0);
console.log(suma); 

